﻿=== CorporateSource  ===

Contributors: proscriptsell
Requires at least: 4.0
Tested up to: 4.9.6
Stable tag: 1.8
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Magazine WordPress Theme

== Description ==

corporatesource is Responsive One Page Business theme morden and clean style. It makes for corporate/business websites, creative agencies and different businesses. it's good on all major browsers, tablets and phones. Its equipped with the most recent technologies and designed with user in mind to confirm endless freedom to make and customise your website like a professional and without any coding. This versatile, multi-purpose theme is ideal for beginners, while also feature made and extendable for  developers, freelancers and growing businesses.

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.


== Menus ===
Primary

== Copyright ==
CorporateSource WordPress Theme, Copyright (C) 2017 eDataStyle ( proscriptsell )
CorporateSource is distributed under the terms of the GNU GPL


== Changelog ==

= 1.9 =
* Screenshot And Few more css and core fuction updated

= 1.6 =
* Screenshot And Tested 4.8.5

= 1.4 =
* Review Team Feedback

= 1.3 =
* Review Team Feedback

= 1.2 =
* Review Team Feedback

= 1.0 =
* Initial release

== Credits ==

* Based on Underscores http://underscores.me/, (C) 2012-2017 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* normalize.css http://necolas.github.io/normalize.css/, (C) 2012-2016 Nicolas Gallagher and Jonathan Neal, [MIT](http://opensource.org/licenses/MIT)
* Bootstrap: http://getbootstrap.com/, (c) Twitter - [MIT](http://opensource.org/licenses/MIT) ;
* Font Awesome: http://fontawesome.io/, (c) Dave Gandy, CSS - [MIT](http://opensource.org/licenses/MIT) ; Fonts - [SIL OFL 1.1](http://scripts.sil.org/OFL)
* wp-bootstrap-navwalker -https://github.com/wp-bootstrap/wp-bootstrap-navwalker [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Magnific Popup  - https://github.com/dimsemenov/Magnific-Popup [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* trt customizer pro - https://github.com/justintadlock/trt-customizer-pro [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Tether -https://github.com/HubSpot/tether [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* RD Navbar  - https://github.com/ZemezPlugins/rd-navbar GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* TGM Plugin Activation - http://tgmpluginactivation.com/ [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)


*Image Used : -
* https://www.pexels.com/photo/tall-city-buildings-near-beach-shore-during-sunset-634010/ ( CC0 License )
https://pixabay.com/en/typing-computer-desk-hoe-office-849806/
https://pixabay.com/en/night-camera-photographer-canon-1927265/
https://pixabay.com/en/animal-horses-fauna-nature-cavalry-3099035/
https://pixabay.com/en/entrepreneur-startup-start-up-man-593358/
All are Licensed under CC0
