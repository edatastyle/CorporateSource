<?php


require_once get_template_directory() . '/inc/tgm/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'corporatesource_register_required_plugins' );

function corporatesource_register_required_plugins() {
	
	$plugins = array(
		array(
			'name'      => esc_html__('KingComposer', 'corporatesource'),
			'slug'      => 'kingcomposer',
			'required'  => false,
		),
		
		array(
			'name'      => esc_html__('WP Subtitle', 'corporatesource'),
			'slug'      => 'wp-subtitle',
			'required'  => false,
		),

		array(
			'name'      => esc_html__('Contact Form 7', 'corporatesource'),
			'slug'      => 'contact-form-7',
			'required'  => false,
		),
		
		array(
			'name'      => esc_html__('WP Instagram Widget', 'corporatesource'),
			'slug'      => 'wp-instagram-widget',
			'required'  => false,
		),
		

	);

	$config = array(
		'id'           => 'corporatesource',
		'default_path' => '',
		'menu'         => 'tgmpa-install-plugins',
		'has_notices'  => true,
		'dismissable'  => true,
		'dismiss_msg'  => '',
		'is_automatic' => false,
		'message'      => '',
	);

	tgmpa( $plugins, $config );
}
